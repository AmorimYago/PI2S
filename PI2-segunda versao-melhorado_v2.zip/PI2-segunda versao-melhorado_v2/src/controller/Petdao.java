/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author PISCA
 */

import model.Animal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Petdao extends ConectarDao {
    private PreparedStatement ps;// objeto de preparação do comando SQL
    
    public Petdao() {
        super(); // Executa construtor da classe mãe
    }
    
    public void alterar(Animal obj) {
        sql = "UPDATE PETS SET nome= ?, especie= ?, raca= ?, cor=  ?, situacao= ?" ;

        try {
            ps = mycon.prepareStatement(sql);
            ps.setString(1, obj.getNome());
            ps.setString(2, obj.getEspecie());
            ps.setString(3, obj.getRaca());
            ps.setString(4, obj.getCor());
            ps.setString(5, obj.getDetalhes());
            
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Alterado com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Alterar pet!" + err.getMessage());
        }
    }

    public void incluir(Animal obj) {

        /*Cria o comando SQL com 5 parâmetros ?, ?, ?, ?, ? */
        sql = "INSERT INTO pets (nome,especie,raca,cor,sit) VALUES (?,?,?,?,?)";
                      

        try {

            // Envia o SQL para dentro da conexão
            ps = mycon.prepareStatement(sql);

            // Configura a posição de cada parâmetro começando pelo primeiro
            ps.setString(1, obj.getNome());
            ps.setString(2, obj.getEspecie());
            ps.setString(3, obj.getRaca());
            ps.setString(4, obj.getCor());
            ps.setInt(5, obj.getSit());
            ps.execute(); // Finalmente executa o comando sql dentro de ps

            ps.close();// finaliza o comando de execução do sql

            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");

        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir pet!" + err.getMessage());
        }
    }

    public ResultSet buscartodos() {
        // o comando select traz um conjunto de registros
        // e armazena dentro de um ResultSet
        sql = "SELECT * FROM PETS ORDER BY nome ";

        try {   // armazena o comando sql dentro da conexão mycon
            ps = mycon.prepareStatement(sql);

            // retorna um ResultSet com os registros selecionados
            return ps.executeQuery();

        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar usuário!" + err.getMessage());
            // Se haver erros exibe a mensagem e returno nulo dentro 
            // do ResultSet
            return null;
        }
    }

    public ResultSet buscar(Animal obj) {
        // para buscar um registro especifico cria-se um sql com um parãmetro chave
        // no caso a busca está sendo feita pelo cpf do usuario
        sql = "SELECT * FROM PETS WHERE Nome = ?";

        try {   // liga o sql com a conexão atraveś do objeto ps
            ps = mycon.prepareStatement(sql);

            // configura o único parametro existente
            ps.setString(1, obj.getNome());

            // retorna o registro selecionado
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Buscar Pet!" + err.getMessage());
            return null;
        }
    }

    public void excluir(String nome) {

        // configura o comando sql de exclusão delete por ID
        sql = "DELETE FROM PET WHERE ID = '" + nome + "'";

        try { // envia o comando sql para dentro da conexão através de ps
            ps = mycon.prepareStatement(sql);
            // executa o comando delete dentro do mysql
            ps.execute();

            ps.close(); // fecha o objeto usado para executar o comando sql

            JOptionPane.showMessageDialog(null, "Registro Excluido com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Pet!" + err.getMessage());
        }
    }
    
}
