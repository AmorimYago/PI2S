/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement; // Dentro da conexão permite executar comandos SQL
import javax.swing.JOptionPane;
import model.Usuario;

public class UsuarioDao extends ConectarDao { //Esse código faz o arrombado ser filho da outra arrombada (ConectarDao)

    String sql;
    PreparedStatement ps; // objeto para executar o sql

    public UsuarioDao() { //o tal do consultor
        super();
    }

    public void criarBanco() {
        try {
            sql = "CREATE TABLE IF NOT EXISTS NIVEIS (idNivel int not null,"
                    + "dsNivel varchar(20) not null, "
                    + "primary key(idNivel) ) ";
            ps = con.prepareStatement(sql); // prepara o objeto que irá executar o comando SQL
            ps.execute(); // Executa o comando SQL
            sql = "CREATE TABLE IF NOT EXISTS USUARIOS ("
                    + "cpf varchar(12) not null ,"
                    + "nome varchar(50) not null ,"
                    + "email varchar(50) not null ,"
                    + "celular varchar(20) not null ,"
                    + "idNivel int not null, "
                    + "senha varchar (20) not null, "
                    + "primary key (cpf) )";
            ps = con.prepareStatement(sql); // prepara o objeto que irá executar o comando SQL
            ps.execute(); // Executa o comando SQL
            ps.close(); // Fecha o objeto
            con.close(); // Fecha a conexão
            JOptionPane.showMessageDialog(null, "Banco criado com sucesso...");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao criar banco de dados " + err.getMessage());
        }
    }

    public ResultSet validarLogin(String login, String senha) {
        sql = "Select * from usuarios where email='" + login + "'"
                + " and senha = '" + senha + "'";
        try {
            PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
            ResultSet resul = ps.executeQuery();
            return resul;
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage());
            return null;
        }
    }

    public void incluir(Usuario obj) {
        sql = "INSERT INTO USUARIOS VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, obj.getCpf());
            ps.setString(2, obj.getNome());
            ps.setString(3, obj.getEmail());
            ps.setString(4, obj.getCelular());
            ps.setInt(5, obj.getIdNivel());
            ps.setString(6, obj.getSenha());
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Registro Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir usuário!" + err.getMessage());
        }
    }

}
